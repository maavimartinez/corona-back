module OffersHelper
end
