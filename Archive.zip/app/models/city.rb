class City < ApplicationRecord
    has_many :towns
end
