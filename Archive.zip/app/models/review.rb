class Review < ApplicationRecord
end
