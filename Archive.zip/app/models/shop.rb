class Shop < ApplicationRecord
    belongs_to :town
end
